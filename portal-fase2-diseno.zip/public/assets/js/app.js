(() => {
  // Cabecera: sólida al bajar (solo en la portada)
  const header = document.querySelector('[data-header]');
  if (header && header.hasAttribute('data-hero')) {
    const sync = () => header.classList.toggle('is-solid', window.scrollY > 40);
    sync();
    window.addEventListener('scroll', sync, { passive: true });
  }

  // Menú móvil
  const btn = document.querySelector('[data-menu-btn]');
  const nav = document.querySelector('[data-nav]');
  if (btn && nav) {
    btn.addEventListener('click', () => {
      const open = nav.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', String(open));
      if (header) header.classList.toggle('is-solid', open || window.scrollY > 40 || !header.hasAttribute('data-hero'));
    });
  }

  // Única función de métricas. Cualquier elemento con data-track="nombre" la usa.
  window.track = (event, data = {}) => {
    const body = JSON.stringify({ event, page: location.pathname, ...data });
    if (navigator.sendBeacon) navigator.sendBeacon('/api/track', body);
  };
  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-track]');
    if (el) window.track(el.dataset.track);
  });
})();
