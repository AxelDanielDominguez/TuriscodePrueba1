<?php /** @var string $id @var string $photo @var string $size */ ?>
<a class="tile tile--<?= e($size) ?>" href="<?= e(route_url($id)) ?>">
  <?= img($photo, t("home.cards.$id.alt"), false, 'tile-img') ?>
  <span class="tile-body">
    <strong class="tile-title"><?= e(t("nav.$id")) ?></strong>
    <span><?= e(t("home.cards.$id.text")) ?></span>
  </span>
</a>
