<section class="hero">
  <?= img('slider/1.jpg', t('alt.hero'), true) ?>
  <div class="wrap hero-body">
    <h1><?= e(t('home.title')) ?></h1>
    <p><?= e(t('home.subtitle')) ?></p>
    <p class="actions">
      <a class="btn" href="<?= e(route_url('rates')) ?>" data-track="cta_rates_hero"><?= e(t('home.cta_rates')) ?></a>
      <a class="btn btn--ghost" href="<?= e(route_url('location')) ?>"><?= e(t('home.cta_location')) ?></a>
    </p>
  </div>
</section>

<div class="wrap">
  <ul class="facts">
    <?php foreach (['distance', 'rooms', 'pool'] as $k): ?>
    <li><strong><?= e(t("home.facts.$k.value")) ?></strong><span><?= e(t("home.facts.$k.label")) ?></span></li>
    <?php endforeach; ?>
  </ul>
</div>

<section class="section wrap why">
  <h2><?= e(t('home.why_title')) ?></h2>
  <div>
    <?php foreach (['location', 'comfort', 'all'] as $k): ?>
    <article>
      <h3><?= e(t("home.why.$k.title")) ?></h3>
      <p><?= e(t("home.why.$k.text")) ?></p>
    </article>
    <?php endforeach; ?>
  </div>
</section>

<section class="section wrap tiles-section">
  <h2><?= e(t('home.tiles_title')) ?></h2>
  <div class="tiles">
    <?= partial('tile', ['id' => 'rooms', 'photo' => 'slider/5.jpg', 'size' => 'wide']) ?>
    <?= partial('tile', ['id' => 'pool', 'photo' => 'pileta/pileta-3.webp', 'size' => 'narrow']) ?>
    <?= partial('tile', ['id' => 'spa', 'photo' => 'spa/spa-8.webp', 'size' => 'narrow']) ?>
    <?= partial('tile', ['id' => 'restaurant', 'photo' => 'slider/6.jpg', 'size' => 'wide']) ?>
  </div>
</section>

<section class="band">
  <div class="wrap section band-grid">
    <div>
      <h2><?= e(t('home.where_title')) ?></h2>
      <p><?= e(t('home.where_text')) ?></p>
    </div>
    <div>
      <address><?= e(config('address.street')) ?><br><?= e(config('address.city')) ?>, <?= e(config('address.region')) ?></address>
      <p><a class="btn" href="<?= e(route_url('location')) ?>"><?= e(t('home.cta_location')) ?></a></p>
    </div>
  </div>
</section>
